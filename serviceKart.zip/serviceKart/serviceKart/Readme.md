# ServiceKart

**ServiceKart** is a web-based platform that connects users with local service professionals (electricians, cleaners, etc.). The platform includes:

- User login, registration, service booking
- Service agent dashboard to manage requests
- Admin panel to manage users, agents, and bookings
- MySQL database
- Node.js backend
- HTML/CSS/JS frontend

## 📁 Project Structure

